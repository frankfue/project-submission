package com.example.mywebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
