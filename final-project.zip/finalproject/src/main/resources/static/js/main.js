$(document).ready(function() {

    /* Navigation burger onclick side navigation show */
    $('.burger-container').on('click', function() {
        $('.main-navigation').toggle('slow');

        if($('#myBtn').hasClass('change')) {
            $('body').addClass('stop-scroll');
        } else {
            $('body').removeClass('stop-scroll');
        }
    });

    /* About me slider */
    $('.about-me-slider').slick({
        slidesToShow: 1,
        prevArrow: '<span class="span-arrow slick-prev"><</span>',
        nextArrow: '<span class="span-arrow slick-next">></span>'
    });

    /* Blog slider */
    $('.blog-slider').slick({
        slidesToShow: 2,
        prevArrow: '<span class="span-arrow slick-prev"><</span>',
        nextArrow: '<span class="span-arrow slick-next">></span>',
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    });

    // Check session state and update UI
    function updateLoginStatus() {
        if (sessionStorage.getItem('isAuthenticated') === 'true') {
            // User is logged in
            $('.login-message').text('Welcome back, ' + sessionStorage.getItem('username') + '!').show();
            $('.logout-message').hide();
            $('#username').val('');  // Clear the username input field
            $('#password').val('');  // Clear the password input field
        } else {
            // User is logged out
            $('.login-message').text('You have been logged out. Goodbye!').show();
            $('.logout-message').hide();
        }
    }

    // On document ready, update login status
    updateLoginStatus();

    // Event listener for login
    $('#loginButton').on('click', function() {
        // Example login logic, you would normally verify these fields against a database
        var username = $('#username').val();
        var password = $('#password').val();

        // Assume a successful login for demonstration purposes
        sessionStorage.setItem('isAuthenticated', 'true');
        sessionStorage.setItem('username', username);
        updateLoginStatus();
    });

    // Event listener for logout
    $('#logoutButton').on('click', function() {
        sessionStorage.setItem('isAuthenticated', 'false');
        sessionStorage.removeItem('username');
        updateLoginStatus();
    });
    
    // Onscroll number counter
    var counta = 0;
    $(window).scroll(function(e) {
        var statisticNumbers = $('.single-count');
        if(statisticNumbers.length) {
            var oTop = statisticNumbers.offset().top - window.innerHeight;
            if (counta == 0 && $(window).scrollTop() > oTop) {
                $('.count').each(function() {
                    var $this = $(this),
                    countTo = $this.attr('data-count');
                    $({
                        countNum: $this.text()
                    }).animate({
                        countNum: countTo
                    },
                    {
                        duration: 2000,
                        easing: 'swing',
                        step: function() {
                            $this.text(Math.floor(this.countNum));
                        },
                        complete: function() {
                            $this.text(this.countNum);
                        }
                    });
                });
                counta = 1;
            }
        }
    });
});